'use strict';
const $ = (id) => document.getElementById(id);
const nav = $('nav');
$('menu-toggle').addEventListener('click', () => { const opened = nav.classList.toggle('open'); $('menu-toggle').setAttribute('aria-expanded', String(opened)); });
nav.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {nav.classList.remove('open');$('menu-toggle').setAttribute('aria-expanded','false');}));
const dialog = $('gesture-dialog');
$('guide-button').addEventListener('click', () => dialog.showModal());
$('close-guide').addEventListener('click', () => dialog.close());
$('camera-button').addEventListener('click', () => { $('lab-status').textContent = 'La cámara y el seguimiento de manos se integrarán en la etapa 3. No se ha activado ninguna cámara.'; });
$('reset-button').addEventListener('click', () => { $('lab-status').textContent = 'Aún no hay un modelo 3D que reiniciar. Se añadirá en la etapa 2.'; });
document.querySelectorAll('[data-correct]').forEach(button => button.addEventListener('click', () => {
 const correct = button.dataset.correct === 'true';
 $('quiz-result').textContent = correct ? '¡Correcto! Una salida digital puede encender o apagar un LED.' : 'Intenta otra vez: piensa en cómo se controla una luz.';
}));
