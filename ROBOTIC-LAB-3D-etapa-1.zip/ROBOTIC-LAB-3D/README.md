# ROBOTIC LAB 3D — Etapa 1
Integrantes: Juan Varela, Isaac Teheran y Andres Ramirez.

## Ejecutar
Abre `index.html` en el navegador para revisar la interfaz. Para las etapas con cámara y módulos JavaScript, ejecuta un servidor local desde esta carpeta:

```bash
python -m http.server 8000
```

Luego visita http://localhost:8000

## Estado
Esta entrega incluye navegación adaptable, secciones educativas introductorias, una guía descriptiva de gestos y una pregunta de evaluación funcional. El escenario 3D, la cámara, el reconocimiento de gestos y los experimentos simulados aún no están implementados. Los botones relacionados informan esto claramente.

## Siguientes etapas
2. Añadir Three.js, modelos 3D y controles de ratón (`js/three-scene.js`).
3. Integrar cámara y MediaPipe (`js/hand-tracking.js`).
4. Programar y validar cinco gestos.
5. Completar guía animada y práctica de gestos (`js/gesture-guide.js`).
6. Ampliar Arduino y Micro:bit (`js/arduino.js`, `js/microbit.js`).
7. Implementar experimentos (`js/circuits.js`).
8. Implementar desafíos (`js/challenges.js`).
9. Integrar y probar en navegador con cámara.
